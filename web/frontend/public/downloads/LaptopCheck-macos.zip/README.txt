======================================================================
  LAPTOPCHECK v1.0.0 — SAFE macOS HARDWARE DIAGNOSTIC COLLECTOR
======================================================================

SAFETY GUARANTEES:
- 100% Read-Only: NEVER deletes, modifies, or writes to your files.
- Safe for older MacBooks (Intel & Apple Silicon M1-M4).
- Privacy First: Serials and personal account info are redacted.

HOW TO RUN:
1. Open Terminal.app
2. Extract this folder and run:
   chmod +x scan_macos.sh && ./scan_macos.sh
3. The collector reads genuine battery health (cycle count & wear),
   CPU topology, Unified Memory, and Storage.
4. Generates 'laptop_specs.json' locally and opens the visual report.

Thank you for using LaptopCheck v1.0.0!
