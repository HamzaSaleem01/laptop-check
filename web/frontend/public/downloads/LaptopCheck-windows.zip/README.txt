======================================================================
  LAPTOPCHECK v1.0.0 — SAFE WINDOWS HARDWARE DIAGNOSTIC COLLECTOR
======================================================================

SAFETY GUARANTEES:
- 100% Read-Only: NEVER deletes, modifies, or writes to your personal files.
- Safe for 5+ Year Old Laptops: Never runs destructive stress tests.
- Privacy First: Serial numbers and hostnames are automatically redacted.

HOW TO RUN:
1. Right-click 'LaptopCheck_Windows.bat' and select 'Run as Administrator'
   (or run in regular PowerShell with: powershell -ExecutionPolicy Bypass -File .\scan.ps1)
2. The collector will inspect CPU, RAM channels, Storage health, and ACPI Battery wear.
3. It will generate 'laptop_specs.json' locally and display the full diagnostic report.

Thank you for using LaptopCheck v1.0.0!
